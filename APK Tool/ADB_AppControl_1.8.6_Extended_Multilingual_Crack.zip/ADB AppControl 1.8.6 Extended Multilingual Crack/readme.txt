Cấp quyền APP bằng ADB qua phần mền 
Code : adb shell id -u